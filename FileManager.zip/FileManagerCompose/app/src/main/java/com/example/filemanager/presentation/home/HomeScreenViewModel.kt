package com.example.filemanager.presentation.home

import dagger.hilt.android.lifecycle.HiltViewModel


class HomeScreenViewModel  {
}