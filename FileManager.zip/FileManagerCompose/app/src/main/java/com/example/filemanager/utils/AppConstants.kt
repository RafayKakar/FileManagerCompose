package com.example.filemanager.utils

object AppConstants {
    const val USER_SETTINGS = "user_settings"
    const val APP_ENTRY = "app_entry"
}