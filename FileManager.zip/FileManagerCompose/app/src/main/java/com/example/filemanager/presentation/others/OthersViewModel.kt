package com.example.filemanager.presentation.others

class OthersViewModel {
}