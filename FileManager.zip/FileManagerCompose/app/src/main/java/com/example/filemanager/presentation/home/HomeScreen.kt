package com.example.filemanager.presentation.home

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun HomeScreen() {
    Text(text = "Home")
}