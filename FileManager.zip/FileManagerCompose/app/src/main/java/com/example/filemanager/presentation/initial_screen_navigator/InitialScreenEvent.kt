package com.example.filemanager.presentation.initial_screen_navigator

sealed class InitialScreenEvent {

    object SaveAppEntry: InitialScreenEvent()

}